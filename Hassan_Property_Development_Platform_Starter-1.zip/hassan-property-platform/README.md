# Hassan Property Development Project — secure starter

This is a **backend starter**, not a live money-handling product. It uses PKR as the ledger currency and keeps all real-money endpoints locked by default because the company authorization is pending.

## Included
- Express API, PostgreSQL + Prisma schema
- Password hashing, signed HTTP-only session cookie, rate limiting and security headers
- User registration/login and dashboard APIs
- Package listing and admin package creation
- Deposit request/review API scaffold, ledger and audit log
- Explicit compliance lock for deposits, investments and payment settlement
- Basic public landing page

## Run locally
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env`; set `DATABASE_URL` and a random `JWT_SECRET` (32+ chars).
3. Run `npm install`
4. Run `npx prisma generate`
5. Run `npx prisma migrate dev --name init`
6. Run `npm run dev`
7. Open `http://localhost:3000`

## Important security / launch requirements
- **Do not deploy this as a live investment/payment service yet.** `REAL_MONEY_ENABLED=false` is intentional.
- Obtain Pakistan-specific legal advice and all required approvals/registrations for the exact investment structure and solicitation model before accepting funds or advertising returns. Company registration alone is not proof of authorization.
- Obtain written merchant onboarding and API credentials from JazzCash/Easypaisa/bank/acquirer. Do not collect card/bank credentials yourself.
- Add provider webhook signature verification, idempotency keys, reconciliation, refund/dispute handling and payout verification before any settlement feature is enabled.
- Add CSRF protection or a robust same-origin CSRF strategy before production; configure HTTPS, secure cookie domain, backups, monitoring, secrets management and penetration testing.
- Create the first ADMIN account through a controlled one-time provisioning script or direct secure database operation. Never expose public admin registration.
- Configure a real email verification and password reset flow, MFA for admins, KYC/AML and sanctions checks as advised by qualified counsel/compliance professionals.
- The sample ledger is a technical starting point. Have an accountant and security engineer review double-entry accounting, segregation of client funds, custody and reconciliation before production.
- Do not promise fixed/guaranteed returns. Disclose project ownership, title/approvals, risks, fees, timelines and investor rights in reviewed contracts.

## API outline
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/status`
- Authenticated: `GET /api/dashboard`, `GET /api/packages`
- Compliance locked: `POST /api/deposit-requests`, `POST /api/withdrawal-requests`, `POST /api/investments`
- Admin: `GET /api/admin/overview`, `GET /api/admin/deposit-requests`, `POST /api/admin/packages`
- Admin settlement endpoint remains compliance locked.

This starter intentionally does not contain live JazzCash/Easypaisa credentials, bank transfer automation, KYC vendor, or an enabled payout rail.
