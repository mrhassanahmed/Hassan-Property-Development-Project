import { Router } from 'express';
import { z } from 'zod';
import { prisma } from './server.js';
import { requireAuth, complianceLock } from './middleware.js';
const router = Router();
router.use(requireAuth);
router.get('/dashboard', async (req, res) => {
  const [entries, investments, requests] = await Promise.all([
    prisma.ledgerEntry.findMany({ where: { userId: req.user.id, status: 'POSTED' } }),
    prisma.investment.findMany({ where: { userId: req.user.id }, include: { package: true } }),
    prisma.paymentRequest.findMany({ where: { userId: req.user.id }, orderBy: { createdAt: 'desc' }, take: 20 })
  ]);
  const balance = entries.reduce((sum, e) => sum + Number(e.amount), 0);
  res.json({ currency: 'PKR', availableBalance: balance, investments, paymentRequests: requests });
});
router.get('/packages', async (_req, res) => {
  const packages = await prisma.package.findMany({ where: { active: true }, orderBy: { minAmount: 'asc' } });
  res.json(packages);
});
const paymentSchema = z.object({
  method: z.enum(['JAZZCASH', 'EASYPAISA', 'BANK_TRANSFER']),
  amount: z.number().positive().max(100000000),
  reference: z.string().min(4).max(100)
});
// Endpoint intentionally locked while company authorization is pending.
router.post('/deposit-requests', complianceLock, async (req, res) => {
  const parsed = paymentSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid payment request.' });
  const request = await prisma.paymentRequest.create({ data: { ...parsed.data, userId: req.user.id } });
  res.status(201).json(request);
});
router.post('/withdrawal-requests', complianceLock, (_req, res) => {
  res.status(501).json({ error: 'Connect an approved payout provider and implement verified beneficiary checks before enabling withdrawals.' });
});
router.post('/investments', complianceLock, async (req, res) => {
  const schema = z.object({ packageId: z.string(), amount: z.number().positive(), termsRef: z.string().min(1) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid investment request.' });
  const p = await prisma.package.findFirst({ where: { id: parsed.data.packageId, active: true } });
  if (!p || parsed.data.amount < Number(p.minAmount) || (p.maxAmount && parsed.data.amount > Number(p.maxAmount))) return res.status(400).json({ error: 'Amount outside package limits.' });
  const investment = await prisma.investment.create({ data: { ...parsed.data, userId: req.user.id } });
  res.status(201).json(investment);
});
export default router;