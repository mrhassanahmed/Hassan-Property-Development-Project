import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from './server.js';
import { requireAuth } from './middleware.js';
const router = Router();
const registerSchema = z.object({ name: z.string().min(2).max(80), email: z.string().email().max(160), password: z.string().min(12).max(128) });
router.post('/register', async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Use a valid name, email and password of at least 12 characters.' });
  const { name, email, password } = parsed.data;
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({ data: { name, email: email.toLowerCase(), passwordHash } });
    res.status(201).json({ id: user.id, name: user.name, email: user.email, message: 'Account created. Investment and payment features are compliance-locked.' });
  } catch { res.status(409).json({ error: 'An account with this email may already exist.' }); }
});
router.post('/login', async (req, res) => {
  const email = String(req.body?.email || '').toLowerCase();
  const password = String(req.body?.password || '');
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ error: 'Invalid email or password.' });
  const token = jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: '8h' });
  res.cookie('session', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', maxAge: 8 * 60 * 60 * 1000 });
  res.json({ id: user.id, name: user.name, role: user.role });
});
router.post('/logout', (_req, res) => { res.clearCookie('session', { httpOnly: true, sameSite: 'strict' }); res.json({ ok: true }); });
router.get('/me', requireAuth, (req, res) => res.json({ id: req.user.id, name: req.user.name, email: req.user.email, role: req.user.role }));
export default router;