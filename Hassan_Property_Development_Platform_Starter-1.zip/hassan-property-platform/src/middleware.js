import jwt from 'jsonwebtoken';
import { prisma } from './server.js';

export async function requireAuth(req, res, next) {
  try {
    const token = req.cookies?.session;
    if (!token) return res.status(401).json({ error: 'Please sign in.' });
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user) return res.status(401).json({ error: 'Invalid session.' });
    req.user = user;
    next();
  } catch { res.status(401).json({ error: 'Session expired or invalid.' }); }
}
export function requireAdmin(req, res, next) {
  if (req.user?.role !== 'ADMIN') return res.status(403).json({ error: 'Admin access required.' });
  next();
}
export function complianceLock(req, res, next) {
  if (process.env.REAL_MONEY_ENABLED !== 'true') {
    return res.status(423).json({ error: 'Real-money activity is locked pending regulatory authorization and payment-provider approval.' });
  }
  next();
}