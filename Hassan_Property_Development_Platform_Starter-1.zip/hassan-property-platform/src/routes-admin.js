import { Router } from 'express';
import { z } from 'zod';
import { prisma } from './server.js';
import { requireAuth, requireAdmin, complianceLock } from './middleware.js';
const router = Router();
router.use(requireAuth, requireAdmin);
router.get('/overview', async (_req, res) => {
  const [users, deposits, withdrawals, investments, pending] = await Promise.all([
    prisma.user.count(), prisma.paymentRequest.count(), prisma.ledgerEntry.count({ where: { type: 'WITHDRAWAL' } }),
    prisma.investment.count(), prisma.paymentRequest.count({ where: { status: 'PENDING' } })
  ]);
  res.json({ users, depositRequests: deposits, withdrawalLedgerEntries: withdrawals, investments, pendingDeposits: pending });
});
router.get('/deposit-requests', async (_req, res) => {
  res.json(await prisma.paymentRequest.findMany({ include: { user: { select: { name: true, email: true } } }, orderBy: { createdAt: 'desc' } }));
});
// Settlement is deliberately unavailable until regulatory and merchant approvals are complete.
router.post('/deposit-requests/:id/review', complianceLock, async (req, res) => {
  const schema = z.object({ decision: z.enum(['APPROVED', 'REJECTED']), note: z.string().max(500).optional() });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid review.' });
  const request = await prisma.paymentRequest.findUnique({ where: { id: req.params.id } });
  if (!request || request.status !== 'PENDING') return res.status(404).json({ error: 'Pending request not found.' });
  const updated = await prisma.$transaction(async tx => {
    const r = await tx.paymentRequest.update({ where: { id: request.id }, data: { status: parsed.data.decision, adminNote: parsed.data.note, reviewedAt: new Date() } });
    if (parsed.data.decision === 'APPROVED') {
      await tx.ledgerEntry.create({ data: { userId: request.userId, type: 'DEPOSIT', status: 'POSTED', amount: request.amount, reference: `DEP-${request.id}`, description: 'Admin-verified deposit' } });
    }
    await tx.auditLog.create({ data: { actorId: req.user.id, action: `DEPOSIT_${parsed.data.decision}`, entityType: 'PaymentRequest', entityId: request.id } });
    return r;
  });
  res.json(updated);
});
router.post('/packages', async (req, res) => {
  const schema = z.object({ name: z.string().min(2), description: z.string().min(5), minAmount: z.number().positive(), maxAmount: z.number().positive().optional() });
  const p = schema.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Invalid package.' });
  const result = await prisma.package.create({ data: { ...p.data } });
  await prisma.auditLog.create({ data: { actorId: req.user.id, action: 'PACKAGE_CREATED', entityType: 'Package', entityId: result.id } });
  res.status(201).json(result);
});
export default router;