import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { PrismaClient } from '@prisma/client';
import authRoutes from './routes-auth.js';
import userRoutes from './routes-user.js';
import adminRoutes from './routes-admin.js';

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  throw new Error('JWT_SECRET must be set to a random secret of at least 32 characters.');
}
const app = express();
export const prisma = new PrismaClient();

app.use(helmet());
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.use(express.static('public'));

app.get('/api/status', (_req, res) => res.json({
  service: 'Hassan Property Development Project',
  currency: 'PKR',
  mode: process.env.REAL_MONEY_ENABLED === 'true' ? 'ENABLED_BY_OPERATOR' : 'COMPLIANCE_LOCKED',
  message: 'Payment and investment transactions remain disabled until approvals and merchant integrations are verified.'
}));
app.use('/api/auth', authRoutes);
app.use('/api', userRoutes);
app.use('/api/admin', adminRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Hassan Property platform listening on ${port}`));
process.on('SIGINT', async () => { await prisma.$disconnect(); process.exit(0); });